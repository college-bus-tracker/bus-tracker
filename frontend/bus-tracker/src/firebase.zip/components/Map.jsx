const Map = () => {
  return (
    <div style={{ width: "100%", height: "400px", background: "#eee", textAlign: "center", lineHeight: "400px" }}>
      [Map Placeholder]
    </div>
  );
};

export default Map;
